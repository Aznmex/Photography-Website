<?php 
  $stocks_names = array("Sunset", "Landscape", "Animals");
  if (isset($_POST[$'suggestion'])) {
	echo $stock_amount = "There are prodcuts of this kind!"; 
  } else {
	echo $stock_amount = "Please enter valid product names!";  
  }
?>